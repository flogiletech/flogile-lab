cp -f /etc/keepalived/* .
cp -f /etc/haproxy/* .
cp -f /etc/kubernetes/manifests/hap* .
cp -f /etc/kubernetes/manifests/keep* .
cp -f /etc/sysctl.d/kub* .
