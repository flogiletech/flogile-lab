cp -f keepalived.conf /etc/keepalived/keepalived.conf
cp -f check_apiserver.sh /etc/keepalived/check_apiserver.sh
cp -f haproxy.cfg /etc/haproxy/haproxy.cfg
cp -f keepalived.yaml /etc/kubernetes/manifests/keepalived.yaml
cp -f haproxy.yaml /etc/kubernetes/manifests/haproxy.yaml
cp -f kubernetes.conf /etc/sysctl.d/kubernetes.conf
