#!/bin/sh

errorExit() {
    echo "*** $*" 1>&2
    exit 1
}

curl --silent --max-time 2 --insecure https://localhost:6444/ -o /dev/null || errorExit "Error GET https://localhost:6444/"
#if ip addr | grep -q 10.10.73.68; then
#    curl --silent --max-time 2 --insecure https://10.10.73.68:6443/ -o /dev/null || errorExit "Error GET https://10.10.73.68:6443/"
#fi

